package constant

type Category string

const (
	MkdirCommand = Category("mkdir")
	CpCommand    = Category("cp")
	LsCommand    = Category("ls")
	CatCommand   = Category("cat")
)

var ReadCategory = map[Category]bool{
	CatCommand: true,
}

func IsCategoryRead(category Category) bool {
	if _, ok := ReadCategory[category]; !ok {
		return false
	}

	return true
}

var WriteCategory = map[Category]bool{
	MkdirCommand: true,
	CpCommand:    true,
}

var ExecuteCategory = map[Category]bool{
	LsCommand: true,
}
