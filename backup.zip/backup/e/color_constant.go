package constant

var (
	ColorGreen = 32
	ColorBlue  = 34

	ColorHiGreen = 92
	ColorHiBlue  = 94
)
