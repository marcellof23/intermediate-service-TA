package constant

const (
	Protocol = "http://"
	ApiVer   = "/api/v1"
)
